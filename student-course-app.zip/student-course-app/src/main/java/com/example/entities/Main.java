package com.example.entities;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class Main {
    public static void main(String[] args) {
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("student-course-app");
        EntityManager em = emf.createEntityManager();

        // If this runs without exceptions, it means the configuration is correct.
        System.out.println("JPA setup is working correctly!");

        em.close();
        emf.close();
    }
}