package com.example.repository;

import com.example.entities.Student;
import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import java.util.List;

public class StudentRepository {

    private EntityManager entityManager;

    public StudentRepository() {
        entityManager = Persistence.createEntityManagerFactory("student-course-app").createEntityManager();
    }

    // Create a new student (Insert)
    public void createStudent(Student student) {
        EntityTransaction transaction = entityManager.getTransaction();
        try {
            transaction.begin();
            entityManager.persist(student);  // Insert new student into the database
            transaction.commit();
        } catch (Exception e) {
            if (transaction.isActive()) {
                transaction.rollback();
            }
            e.printStackTrace();
        }
    }

    // Read a student by ID (Select)
    public Student getStudentById(int studentId) {
        return entityManager.find(Student.class, studentId);  // Find a student by primary key
    }

    // Read all students (Select)
    @SuppressWarnings("unchecked")
    public List<Student> getAllStudents() {
        return entityManager.createQuery("SELECT s FROM Student s").getResultList();  // Query all students
    }

    // Update a student's details
    public void updateStudent(Student student) {
        EntityTransaction transaction = entityManager.getTransaction();
        try {
            transaction.begin();
            entityManager.merge(student);  // Update student details
            transaction.commit();
        } catch (Exception e) {
            if (transaction.isActive()) {
                transaction.rollback();
            }
            e.printStackTrace();
        }
    }

    // Delete a student by ID
    public void deleteStudent(int studentId) {
        EntityTransaction transaction = entityManager.getTransaction();
        try {
            transaction.begin();
            Student student = entityManager.find(Student.class, studentId);
            if (student != null) {
                entityManager.remove(student);  // Delete student from the database
            }
            transaction.commit();
        } catch (Exception e) {
            if (transaction.isActive()) {
                transaction.rollback();
            }
            e.printStackTrace();
        }
    }
}